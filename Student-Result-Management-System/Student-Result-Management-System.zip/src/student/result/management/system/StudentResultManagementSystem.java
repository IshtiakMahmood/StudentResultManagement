/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package student.result.management.system;

/**
 *
 * @author m6444
 */
public class StudentResultManagementSystem {

   public static void main(String[] args) {
        // Create and display the StudentResultForm
        java.awt.EventQueue.invokeLater(() -> {
            new StudentResultForm().setVisible(true);
        });
    }
}

